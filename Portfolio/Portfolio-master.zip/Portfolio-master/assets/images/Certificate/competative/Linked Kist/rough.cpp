#include<iostream>
using namespace std;
int main(){

    int t=5;
    while(t--)
    {
        cout<<t;
        
    }

    
} // namespace std;
